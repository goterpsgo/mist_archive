CREATE PROCEDURE `sp_get_newest_tagged_repos`(IN `repoID`      INT, IN `scID` VARCHAR, IN `category` VARCHAR,
                                              IN `cardinality` INT)
  BEGIN
    prepare stmt from
    "SELECT id
    FROM taggedRepos
    WHERE status = 'True'
          AND repoID = repoID
          AND scID = scID
          AND category = category
          AND id NOT IN (
          select * from (
            SELECT *
              FROM taggedRepos
              WHERE status = 'True'
                    AND repoID = repoID
                    AND scID = scID
                    AND category = category
              ORDER BY timestamp desc
            LIMIT ?
            ) temp_tab
          )
    ORDER BY timestamp"
    ;
    set @cardinality = cardinality;
    execute stmt using @cardinality;
    deallocate prepare stmt;
  end